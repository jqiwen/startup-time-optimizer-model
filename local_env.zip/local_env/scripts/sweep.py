#!/usr/bin/env python3
"""
Extended sweep script for collecting startup times under a wide range of
resource limits and JVM heap / GC / JIT / CDS settings.
"""

import csv
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple

try:
    import requests  # type: ignore
except ImportError:
    print("The 'requests' library is required. Install it via 'pip install requests'.", file=sys.stderr)
    sys.exit(1)

# ---------------------------------------------------------------------------
# Paths

# local_env/
BASE_DIR = Path(__file__).resolve().parent.parent
# local_env/scripts/
SCRIPTS_DIR = BASE_DIR / "scripts"
SCRIPTS_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Configuration values

CPU_LIST: List[str] = [
    "0.5",
    "0.75",
    "1.0",
    "1.25",
    "1.5",
    "2.0",
    "2.5",
    "3.0",
]

MEM_LIST: List[str] = [
    "512M",
    "768M",
    "1G",
    "1.5G",
    "2G",
    "3G",
    "4G",
]

HEAP_LIST: List[str] = [
    "256M",
    "384M",
    "512M",
    "768M",
    "1G",
    "1.25G",
    "1.5G",
    "2G",
    "2.5G",
]

# New knobs

GC_LIST: List[str] = [
    "default",   # JVM default GC
    "g1",        # G1GC
]

JIT_LIST: List[str] = [
    "jit",       # normal JIT (default)
    "int",       # interpreted only (-Xint)
]

CDS_LIST: List[str] = [
    "off",
    "on",
]

GC_FLAGS: Dict[str, str] = {
    "default": "",
    "g1": "-XX:+UseG1GC",
}

JIT_FLAGS: Dict[str, str] = {
    "jit": "",        # normal
    "int": "-Xint",   # interpreted only
}

CDS_FLAGS: Dict[str, str] = {
    "off": "-Xshare:off",
    "on": "-Xshare:on",
}

# Names of the application and sidecar containers
APP_CONTAINER = "app"
SIDECAR_CONTAINER = "sidecar"

HEALTH_URL = "http://localhost:9080/health/ready"
HEALTH_URL_CONTAINER = "http://app:9080/health/ready"

PROMETHEUS_QUERY_URL = "http://localhost:9090/api/v1/query"

READINESS_TIMEOUT = 300
PROMETHEUS_TIMEOUT = 180


def parse_mem_to_mb(value: str) -> float:
    cleaned = value.strip().upper()
    if cleaned.endswith("M"):
        return float(cleaned[:-1])
    if cleaned.endswith("G"):
        return float(cleaned[:-1]) * 1024.0
    raise ValueError(f"Memory value must end with 'M' or 'G': {value}")


def run_cmd(
    cmd: List[str],
    env: Dict[str, str] | None = None,
    capture: bool = False,
    cwd: Path | None = None,
) -> Tuple[int, str, str]:
    """Run a subprocess command and return (returncode, stdout, stderr)."""
    env_vars = os.environ.copy()
    if env:
        env_vars.update(env)
    result = subprocess.run(
        cmd,
        check=False,
        text=True,
        capture_output=capture,
        env=env_vars,
        cwd=str(cwd) if cwd is not None else None,
    )
    return result.returncode, result.stdout if capture else "", result.stderr if capture else ""


def get_default_network() -> str:
    rc, out, _ = run_cmd(["docker", "network", "ls", "--format", "{{.Name}}"], capture=True)
    if rc != 0:
        print("Error listing docker networks", file=sys.stderr)
        sys.exit(1)
    for name in out.strip().splitlines():
        if name.endswith("_default"):
            return name
    return "project_default"


def wait_for_readiness(url: str, timeout: int = READINESS_TIMEOUT) -> bool:
    start = time.time()
    while time.time() - start < timeout:
        try:
            resp = requests.get(url, timeout=2)
            if resp.status_code == 200:
                return True
        except Exception:
            pass
        time.sleep(2)
    return False


def query_prometheus(
    cpus: str,
    memory: str,
    heap: str,
    gc: str,
    jit: str,
    cds: str,
    timeout: int = PROMETHEUS_TIMEOUT,
) -> float:
    """
    Retrieve the app_startup_seconds metric for the given labels.
    """
    query = (
        'app_startup_seconds{app="acmeair",'
        f'cpus="{cpus}",memory="{memory}",heap="{heap}",'
        f'gc="{gc}",jit="{jit}",cds="{cds}"'
    )
    params = {"query": query}
    start = time.time()
    while time.time() - start < timeout:
        try:
            resp = requests.get(PROMETHEUS_QUERY_URL, params=params, timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("status") == "success":
                    result = data.get("data", {}).get("result", [])
                    if result:
                        return float(result[0]["value"][1])
        except Exception:
            pass
        time.sleep(2)
    raise RuntimeError(
        f"Metric not found for cpus={cpus}, memory={memory}, heap={heap}, "
        f"gc={gc}, jit={jit}, cds={cds}"
    )


def stop_stack() -> None:
    """Stop the compose stack and remove volumes; delete any sidecar container."""
    # IMPORTANT: run in BASE_DIR so docker-compose.yml is found
    run_cmd(["docker", "compose", "down", "-v"], cwd=BASE_DIR)
    run_cmd(["docker", "rm", "-f", SIDECAR_CONTAINER])


def start_stack(jvm_args: str) -> None:
    """Start the compose stack, passing JVM arguments via JVM_ARGS env var."""
    print(f"Starting stack with JVM_ARGS: {jvm_args}")
    run_cmd(
        ["docker", "compose", "up", "-d"],
        env={"JVM_ARGS": jvm_args},
        cwd=BASE_DIR,
    )


def configure_app_resources(cpus: str, memory: str) -> None:
    mem_lower = memory.lower()
    rc, _, err = run_cmd(
        ["docker", "update", "--cpus", cpus, "--memory", mem_lower, APP_CONTAINER]
    )
    if rc != 0:
        print(f"Warning: failed to update app resources: {err.strip()}")


def restart_sidecar(cpus: str, memory: str, heap: str, gc: str, jit: str, cds: str, network: str) -> None:
    """Start a new sidecar container with labelled environment variables."""
    run_cmd(["docker", "rm", "-f", SIDECAR_CONTAINER])
    image_name = "project-sidecar"  # ensure you built this image: docker build -t project-sidecar ./sidecar
    run_cmd(
        [
            "docker",
            "run",
            "-d",
            "--name",
            SIDECAR_CONTAINER,
            "-p",
            "9100:9100",
            "-e",
            "APP_NAME=acmeair",
            "-e",
            f"HEALTH_URL={HEALTH_URL_CONTAINER}",
            "-e",
            f"CPUS={cpus}",
            "-e",
            f"CPU_LIMIT={cpus}",
            "-e",
            f"MEMORY={memory}",
            "-e",
            f"MEM_LIMIT={memory}",
            "-e",
            f"HEAP={heap}",
            "-e",
            f"GC={gc}",
            "-e",
            f"JIT={jit}",
            "-e",
            f"CDS={cds}",
            "--network",
            network,
            f"{image_name}:latest",
        ]
    )


def main() -> None:
    network = get_default_network()
    print(f"Detected docker network: {network}")
    results: List[Tuple[str, str, str, str, str, str, float]] = []

    for cpus in CPU_LIST:
        for memory in MEM_LIST:
            for heap in HEAP_LIST:
                # Skip configurations where heap > memory
                try:
                    if parse_mem_to_mb(heap) > parse_mem_to_mb(memory):
                        print(f"Skipping invalid combination: heap {heap} > memory {memory}")
                        continue
                except ValueError as e:
                    print(f"Invalid memory format: {e}")
                    continue

                for gc in GC_LIST:
                    for jit in JIT_LIST:
                        for cds in CDS_LIST:
                            print(
                                f"\n---\nTesting: cpus={cpus}, memory={memory}, "
                                f"heap={heap}, gc={gc}, jit={jit}, cds={cds}"
                            )

                            stop_stack()

                            # Build JVM args
                            jvm_args_parts = [
                                f"-Xms{heap}",
                                f"-Xmx{heap}",
                                GC_FLAGS.get(gc, ""),
                                JIT_FLAGS.get(jit, ""),
                                CDS_FLAGS.get(cds, ""),
                            ]
                            jvm_args = " ".join(p for p in jvm_args_parts if p)

                            start_stack(jvm_args)
                            configure_app_resources(cpus, memory)
                            restart_sidecar(cpus, memory, heap, gc, jit, cds, network)

                            if not wait_for_readiness(HEALTH_URL, READINESS_TIMEOUT):
                                print("Application did not become ready in time; skipping")
                                continue

                            time.sleep(10)

                            try:
                                value = query_prometheus(cpus, memory, heap, gc, jit, cds)
                                print(f"Startup time (s): {value}")
                                results.append((cpus, memory, heap, gc, jit, cds, value))
                            except RuntimeError as e:
                                print(str(e))
                            finally:
                                stop_stack()

    # Write results to local_env/scripts/startup_data.csv
    csv_file = SCRIPTS_DIR / "startup_data.csv"
    with open(csv_file, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            ["cpus", "memory", "heap", "gc", "jit", "cds", "startup_seconds"]
        )
        for row in results:
            writer.writerow(row)

    print(f"Completed. Wrote {len(results)} measurements to {csv_file}.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Interrupted by user.")
